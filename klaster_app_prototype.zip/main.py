import sys
import sqlite3
from PySide6.QtWidgets import (QApplication, QWidget, QTabWidget, QVBoxLayout, QHBoxLayout,
                               QLabel, QLineEdit, QPushButton, QTextEdit, QTableWidget, QTableWidgetItem,
                               QMessageBox, QFileDialog, QDateEdit)
from PySide6.QtCore import Qt, QDate
from db import Database

DB_PATH = "klaster.db"

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Klaster — Учёт (прототип)")
        self.db = Database(DB_PATH)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        tabs = QTabWidget()
        tabs.addTab(self.create_prihod_tab(), "Приход")
        tabs.addTab(self.create_otpus_tab(), "Отпуск")
        tabs.addTab(self.create_tools_tab(), "Инструменты")
        layout.addWidget(tabs)
        self.setLayout(layout)
        self.resize(900,600)

    # --- Приход ---
    def create_prihod_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        form = QHBoxLayout()

        self.p_name = QLineEdit(); self.p_brand = QLineEdit(); self.p_model = QLineEdit()
        self.p_serial = QLineEdit(); self.p_date = QDateEdit(); self.p_date.setCalendarPopup(True)
        self.p_date.setDate(QDate.currentDate())
        self.p_from = QLineEdit(); self.p_comment = QLineEdit()

        form.addWidget(QLabel("Наименование")); form.addWidget(self.p_name)
        form.addWidget(QLabel("Бренд")); form.addWidget(self.p_brand)
        form.addWidget(QLabel("Модель")); form.addWidget(self.p_model)
        form.addWidget(QLabel("Серийный номер")); form.addWidget(self.p_serial)
        v.addLayout(form)

        form2 = QHBoxLayout()
        form2.addWidget(QLabel("Дата поставки")); form2.addWidget(self.p_date)
        form2.addWidget(QLabel("От кого получили")); form2.addWidget(self.p_from)
        form2.addWidget(QLabel("Комментарий")); form2.addWidget(self.p_comment)
        v.addLayout(form2)

        bsave = QPushButton("Добавить в базу")
        bsave.clicked.connect(self.add_prihod)
        v.addWidget(bsave)

        # Table of last entries
        self.prihod_table = QTableWidget(0,8)
        self.prihod_table.setHorizontalHeaderLabels(["id","Наименование","Бренд","Модель","Серийный номер","Дата поставки","От кого","Комментарий"])
        v.addWidget(self.prihod_table)
        brefresh = QPushButton("Обновить список")
        brefresh.clicked.connect(self.load_prihod_table)
        v.addWidget(brefresh)
        self.load_prihod_table()
        return w

    def add_prihod(self):
        name = self.p_name.text().strip()
        brand = self.p_brand.text().strip()
        model = self.p_model.text().strip()
        serial = self.p_serial.text().strip()
        date = self.p_date.date().toString("yyyy-MM-dd")
        source = self.p_from.text().strip()
        comment = self.p_comment.text().strip()
        if not serial:
            QMessageBox.warning(self, "Ошибка", "Серийный номер обязателен")
            return
        if self.db.exists_in_prihod(serial):
            QMessageBox.warning(self, "Дубликат", "Такой серийный номер уже есть в Приходе")
            return
        self.db.insert_prihod(name, brand, model, serial, date, source, comment)
        QMessageBox.information(self, "Готово", "Запись добавлена")
        self.p_serial.clear()
        self.load_prihod_table()

    def load_prihod_table(self):
        rows = self.db.get_prihod_recent(200)
        self.prihod_table.setRowCount(0)
        for r in rows:
            rowpos = self.prihod_table.rowCount()
            self.prihod_table.insertRow(rowpos)
            for c, val in enumerate(r):
                item = QTableWidgetItem(str(val) if val is not None else "")
                self.prihod_table.setItem(rowpos, c, item)

    # --- Отпуск ---
    def create_otpus_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        h = QHBoxLayout()
        self.o_serial = QLineEdit(); self.o_customer = QLineEdit(); self.o_comment = QLineEdit()
        self.o_date = QDateEdit(); self.o_date.setCalendarPopup(True); self.o_date.setDate(QDate.currentDate())
        scan_btn = QPushButton("Скан/Заполнить")
        scan_btn.clicked.connect(self.fill_from_serial)
        save_btn = QPushButton("Добавить отпуск")
        save_btn.clicked.connect(self.add_otpus)
        h.addWidget(QLabel("Серийный номер")); h.addWidget(self.o_serial)
        h.addWidget(scan_btn)
        h.addWidget(QLabel("Дата отпуска")); h.addWidget(self.o_date)
        h.addWidget(QLabel("Покупатель")); h.addWidget(self.o_customer)
        h.addWidget(save_btn)
        v.addLayout(h)

        # auto-filled fields
        auto_h = QHBoxLayout()
        self.o_name = QLineEdit(); self.o_brand = QLineEdit(); self.o_model = QLineEdit()
        auto_h.addWidget(QLabel("Наименование")); auto_h.addWidget(self.o_name)
        auto_h.addWidget(QLabel("Бренд")); auto_h.addWidget(self.o_brand)
        auto_h.addWidget(QLabel("Модель")); auto_h.addWidget(self.o_model)
        v.addLayout(auto_h)

        self.o_table = QTableWidget(0,7)
        self.o_table.setHorizontalHeaderLabels(["id","Серийный номер","Наименование","Бренд","Модель","Дата","Покупатель"])
        v.addWidget(self.o_table)
        brefresh = QPushButton("Обновить список")
        brefresh.clicked.connect(self.load_otpus_table)
        v.addWidget(brefresh)
        return w

    def fill_from_serial(self):
        serial = self.o_serial.text().strip()
        if not serial:
            return
        rec = self.db.find_prihod_by_serial(serial)
        if not rec:
            QMessageBox.warning(self, "Не найден", "Серийный номер не найден в Приходе")
            self.o_name.clear(); self.o_brand.clear(); self.o_model.clear()
            return
        _, name, brand, model, s, date, src, comment = rec
        self.o_name.setText(name or "")
        self.o_brand.setText(brand or "")
        self.o_model.setText(model or "")

    def add_otpus(self):
        serial = self.o_serial.text().strip()
        date = self.o_date.date().toString("yyyy-MM-dd")
        customer = self.o_customer.text().strip()
        comment = self.o_comment.text().strip()
        if not serial:
            QMessageBox.warning(self, "Ошибка", "Серийный номер обязателен")
            return
        status = self.db.get_status_for_otpus(serial)
        if status == "Дубль":
            QMessageBox.warning(self, "Дубль", "Этот серийный номер уже отпущен (или дублируется)")
            return
        self.db.insert_otpus(serial, date, customer, comment)
        QMessageBox.information(self, "Готово", "Отпуск добавлен")
        self.o_serial.clear(); self.o_name.clear(); self.o_brand.clear(); self.o_model.clear()
        self.load_otpus_table()

    def load_otpus_table(self):
        rows = self.db.get_otpus_recent(200)
        self.o_table.setRowCount(0)
        for r in rows:
            rowpos = self.o_table.rowCount()
            self.o_table.insertRow(rowpos)
            for c, val in enumerate(r):
                item = QTableWidgetItem(str(val) if val is not None else "")
                self.o_table.setItem(rowpos, c, item)

    # --- Tools ---
    def create_tools_tab(self):
        w = QWidget(); v = QVBoxLayout(w)
        imp_btn = QPushButton("Импорт из Excel (Приход)")
        imp_btn.clicked.connect(self.import_excel)
        exp_btn = QPushButton("Экспорт базы в Excel (Приход)")
        exp_btn.clicked.connect(self.export_prihod)
        v.addWidget(imp_btn); v.addWidget(exp_btn)
        return w

    def import_excel(self):
        fname, _ = QFileDialog.getOpenFileName(self, "Выбрать файл Excel для импорта", "", "Excel files (*.xlsx *.xls)")
        if not fname:
            return
        from import_from_excel import import_prihod_from_excel
        count = import_prihod_from_excel(fname, DB_PATH)
        QMessageBox.information(self, "Импорт завершён", f"Добавлено записей: {count}")
        self.load_prihod_table()

    def export_prihod(self):
        fname, _ = QFileDialog.getSaveFileName(self, "Сохранить экспорт", "", "Excel files (*.xlsx)")
        if not fname:
            return
        self.db.export_prihod_to_excel(fname)
        QMessageBox.information(self, "Экспорт", "Экспорт завершён")

if __name__ == '__main__':
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())
