import sqlite3
import os
import pandas as pd

class Database:
    def __init__(self, path="klaster.db"):
        self.path = path
        init_needed = not os.path.exists(self.path)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        if init_needed:
            self.init_db()

    def init_db(self):
        c = self.conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS prihod (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            brand TEXT,
            model TEXT,
            serial TEXT UNIQUE,
            date_supply TEXT,
            source TEXT,
            comment TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS otpus (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial TEXT,
            date_out TEXT,
            customer TEXT,
            comment TEXT
        )""")
        self.conn.commit()

    def insert_prihod(self, name, brand, model, serial, date_supply, source, comment):
        c = self.conn.cursor()
        c.execute("INSERT INTO prihod (name,brand,model,serial,date_supply,source,comment) VALUES (?,?,?,?,?,?,?)",
                  (name,brand,model,serial,date_supply,source,comment))
        self.conn.commit()

    def exists_in_prihod(self, serial):
        c = self.conn.cursor()
        c.execute("SELECT 1 FROM prihod WHERE serial = ?", (serial,))
        return c.fetchone() is not None

    def find_prihod_by_serial(self, serial):
        c = self.conn.cursor()
        c.execute("SELECT * FROM prihod WHERE serial = ?", (serial,))
        return c.fetchone()

    def get_prihod_recent(self, limit=200):
        c = self.conn.cursor()
        c.execute("SELECT id,name,brand,model,serial,date_supply,source,comment FROM prihod ORDER BY id DESC LIMIT ?", (limit,))
        return c.fetchall()

    def insert_otpus(self, serial, date_out, customer, comment):
        c = self.conn.cursor()
        c.execute("INSERT INTO otpus (serial,date_out,customer,comment) VALUES (?,?,?,?)",
                  (serial,date_out,customer,comment))
        self.conn.commit()

    def get_otpus_recent(self, limit=200):
        c = self.conn.cursor()
        c.execute("SELECT id,serial, (SELECT name FROM prihod p WHERE p.serial=otpus.serial) as name, (SELECT brand FROM prihod p WHERE p.serial=otpus.serial) as brand, (SELECT model FROM prihod p WHERE p.serial=otpus.serial) as model, date_out, customer FROM otpus ORDER BY id DESC LIMIT ?", (limit,))
        return c.fetchall()

    def get_status_for_otpus(self, serial):
        c = self.conn.cursor()
        # check if already in otpus
        c.execute("SELECT 1 FROM otpus WHERE serial = ?", (serial,))
        if c.fetchone():
            return "Дубль"
        # check in prihod
        c.execute("SELECT 1 FROM prihod WHERE serial = ?", (serial,))
        if c.fetchone():
            return "OK"
        return "Не найден"

    def export_prihod_to_excel(self, fname):
        df = pd.read_sql_query("SELECT id,name,brand,model,serial,date_supply,source,comment FROM prihod", self.conn)
        df.to_excel(fname, index=False)
