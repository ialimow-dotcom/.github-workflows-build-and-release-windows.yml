import pandas as pd
import sqlite3
import sys

def import_prihod_from_excel(filename, dbpath="klaster.db"):
    df = pd.read_excel(filename)
    # Try to detect columns
    colmap = {}
    for c in df.columns:
        lc = str(c).lower()
        if "сер" in lc or "sn"==lc.strip() or "serial" in lc:
            colmap["serial"]=c
        if "наимен" in lc or "name" in lc:
            colmap["name"]=c
        if "бренд" in lc or "brand" in lc:
            colmap["brand"]=c
        if "модел" in lc or "model" in lc:
            colmap["model"]=c
        if "дат" in lc or "date" in lc:
            colmap["date"]=c
        if "от" in lc or "source" in lc:
            colmap["source"]=c
    conn = sqlite3.connect(dbpath)
    cur = conn.cursor()
    added = 0
    for idx, row in df.iterrows():
        serial = str(row.get(colmap.get("serial",""), "")).strip()
        if not serial or serial.lower()=="nan":
            continue
        name = str(row.get(colmap.get("name",""), "")).strip()
        brand = str(row.get(colmap.get("brand",""), "")).strip()
        model = str(row.get(colmap.get("model",""), "")).strip()
        date = row.get(colmap.get("date",""), "")
        source = str(row.get(colmap.get("source",""), "")).strip()
        try:
            cur.execute("INSERT INTO prihod (name,brand,model,serial,date_supply,source,comment) VALUES (?,?,?,?,?,?,?)",
                        (name,brand,model,serial,str(date),source,"import"))
            added += 1
        except Exception as e:
            # skip duplicates
            pass
    conn.commit()
    conn.close()
    return added

if __name__ == "__main__":
    if len(sys.argv)<2:
        print("Usage: import_from_excel.py file.xlsx [dbpath]")
    else:
        n = import_prihod_from_excel(sys.argv[1], sys.argv[2] if len(sys.argv)>2 else "klaster.db")
        print("Added:", n)
