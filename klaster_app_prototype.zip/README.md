# Klaster — Prototype PC App (PySide6 + SQLite)

This is a minimal prototype desktop application that implements the Excel logic you had:
- "Приход" (incoming) database of items with serial numbers
- "Отпуск" (outgoing/sales) where entering/scanning a serial fills name/brand/model
- Duplicate and "not found" checks are implemented in DB logic

## Files
- `main.py` — main PySide6 GUI application
- `db.py` — simple SQLite wrapper and helper functions
- `import_from_excel.py` — import utility to load приход data from Excel
- `requirements.txt` — Python dependencies
- `run_demo.sh` — helper to run locally in the container
- `build_instructions.txt` — notes on building .exe with PyInstaller

## Run (local)
1. Create virtualenv:
   ```bash
   python -m venv venv
   source venv/bin/activate   # on Windows: venv\\Scripts\\activate
   pip install -r requirements.txt
   python main.py
   ```

## Import Excel
Use `Инструменты -> Импорт из Excel` in the app, or run:
```bash
python import_from_excel.py path_to_file.xlsx klaster.db
```

## Build .exe
See `build_instructions.txt` for a minimal PyInstaller approach.
